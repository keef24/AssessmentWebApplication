﻿using Microsoft.AspNetCore.SignalR;
using ProjectWork.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ProjectWork
{
    public class SignalHub : Hub
    {
        public async Task SendMessage(string user, string message)
        {
            await Clients.All.SendAsync("ReceiveMessage", user, message);
        }
        public async Task SaveModel(string modelName, int year)
        {
            // Validate the inputs (you can add more validation as needed)
            if (string.IsNullOrEmpty(modelName) || year <= 0)
            {
                // Handle validation errors and return an appropriate response to the client
                await Clients.Caller.SendAsync("SaveModelResult", "Validation failed. Please provide valid inputs.");
                return;
            }

            // Assuming you have a database or data store, save the model here
            // Replace this with your actual data saving logic

            // After saving, you can broadcast a notification to all clients
            await Clients.All.SendAsync("ModelSavedNotification", modelName, year);

            // Alternatively, you can send a success message to the caller
            await Clients.Caller.SendAsync("SaveModelResult", "Model saved successfully.");
        }
        public async Task DeleteModel(int modelId)
        {
            // Implement your logic to delete the model with the specified modelId
            // This could involve database operations, data removal, etc.

            // Once the model is deleted, you can notify clients, e.g., by sending a confirmation
            await Clients.All.SendAsync("ModelDeleted", modelId);
        }
        public async Task<IEnumerable<Model>> GetModelList()
        {
            // Replace this with your actual logic to fetch the list of models
            // Example: You can fetch the list from a database or other data source
            var models = FetchModelsFromDatabase();

            return models;
        }
        private IEnumerable<Model> FetchModelsFromDatabase()
        {
            // Replace this with your database retrieval logic
            // Example: You might use Entity Framework to query the database
            // Here, we provide a simple hardcoded list as an example
            var models = new List<Model>
        {
            new Model { ModelId = 1, ModelName = "Model A", Year = 2022 },
            new Model { ModelId = 2, ModelName = "Model B", Year = 2023 },
            new Model { ModelId = 3, ModelName = "Model C", Year = 2021 }
        };

            return models;
        }
        public async Task EditModel(int modelId)
        {
            // Implement your logic to edit the model with the specified modelId
            // This could involve opening an edit modal, performing updates, etc.

            // Once the model is edited, you can notify clients, e.g., by sending a confirmation
            await Clients.All.SendAsync("ModelEdited", modelId);
        }
        public async Task SaveMake(string makeName)
        {
            // Implement your logic to save the make with the provided MakeName
            // This could involve database operations, validation, etc.

            // Once the make is saved, you can notify clients, e.g., by sending a confirmation
            await Clients.All.SendAsync("MakeSaved", makeName);
        }
        public async Task EditMake(int makeId)
        {
            // Implement your logic to edit the make with the provided makeId
            // This could involve database operations, validation, etc.

            // Once the make is edited, you can notify clients, e.g., by sending a confirmation
            await Clients.All.SendAsync("MakeEdited", makeId);
        }
        public async Task DeleteMake(int makeId)
        {
            // Implement your logic to delete the make with the provided makeId
            // This could involve database operations, validation, etc.

            // Once the make is deleted, you can notify clients, e.g., by sending a confirmation
            await Clients.All.SendAsync("MakeDeleted", makeId);
        }
        public async Task<IEnumerable<Make>> GetMakes()
        {
            // Implement your logic to fetch a list of makes
            // This could involve database queries, data retrieval, etc.

            // Replace the following line with your actual list of makes retrieval
            var makes = new List<Make>
        {
            new Make { MakeId = 1, MakeName = "Make 1" },
            new Make { MakeId = 2, MakeName = "Make 2" },
            // Add more makes as needed
        };

            return makes;
        }
        public async Task<IEnumerable<Truck>> GetTruckList()
        {
            // Replace this with your logic to fetch the list of trucks from your data source
            // For example, you can query a database or retrieve the list from a service
            // Return the dummy truck data
            var trucks = new List<Truck>
        {
            new Truck
            {

                MakeId = 1, // Replace with actual MakeId
                ModelId = 1, // Replace with actual ModelId
                LoadCapacityTons = 10.5,
                HasTrailer = false,
                // Add other properties as needed
            },
            new Truck
            {

                MakeId = 2, // Replace with actual MakeId
                ModelId = 2, // Replace with actual ModelId
                LoadCapacityTons = 15.0,
                HasTrailer = true,
                // Add other properties as needed
            },
            // Add more dummy trucks as needed
        };
            return trucks;
        }

        // Define a method to get the list of cars
        public async Task<IEnumerable<Car>> GetCarList()
        {
            var cars = new List<Car>
        {
            new Car
            {
                MakeId = 1, // Replace with actual MakeId
                ModelId = 1, // Replace with actual ModelId
                NumberOfDoors = 4,
                IsConvertible = false,
                // Add other properties as needed
            },
            new Car
            {
                MakeId = 2, // Replace with actual MakeId
                ModelId = 2, // Replace with actual ModelId
                NumberOfDoors = 2,
                IsConvertible = true,
                // Add other properties as needed
            },
            // Add more dummy cars as needed
        };
            return cars;
        }

        public async Task SaveCar(int make, int model, int noOfDoors)
        {

            // Implement your logic to save the car with the provided details
            // This could involve database operations, validation, etc.

            // Once the car is saved, you can notify clients, e.g., by sending a confirmation
            await Clients.All.SendAsync("CarSaved", make, model, noOfDoors);
        }

        public async Task Drive(string vehicleId)
        {
            // For example, you can update the vehicle's status or perform other actions.

            // Broadcast a message to all clients that the vehicle with vehicleId is being driven.
            await Clients.All.SendAsync("VehicleDriven", vehicleId);
        }

        public async Task Reverse(string vehicleId)
        {
            // Implement the logic to reverse the vehicle with the provided vehicleId
            // For example, you can update the vehicle's status or perform other actions.

            // Broadcast a message to all clients that the vehicle with vehicleId is being reversed.
            await Clients.All.SendAsync("VehicleReversed", vehicleId);
        }

    }
}