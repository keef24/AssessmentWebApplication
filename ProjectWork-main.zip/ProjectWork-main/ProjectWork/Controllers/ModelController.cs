﻿using Microsoft.AspNetCore.Mvc;
using ProjectWork.Models;
using System.Threading.Tasks;

namespace ProjectWork.Controllers
{
    public class ModelController : Controller
    {
        //private readonly ApplicationDbContext _context;

        //public VehicleModelsController(ApplicationDbContext context)
        //{
        //    _context = context;
        //}

        // GET: VehicleModels
        public async Task<IActionResult> Index()
        {
            //var vehicleModels = await _context.VehicleModels.ToListAsync();
            return View();
        }

        // GET: VehicleModels/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: VehicleModels/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Id,Name,Year,Make")] Model vehicleModel)
        {
            if (ModelState.IsValid)
            {
                //_context.Add(vehicleModel);
                //await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(vehicleModel);
        }

        // GET: VehicleModels/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            //var vehicleModel = await _context.VehicleModels.FindAsync(id);
            //if (vehicleModel == null)
            //{
            //    return NotFound();
            //}
            ////return View(vehicleModel);
            return View();
        }

        // POST: VehicleModels/Edit/5
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Year,Make")] Model vehicleModel)
        //{
        //    if (id != vehicleModel.Id)
        //    {
        //        return NotFound();
        //    }

        //    if (ModelState.IsValid)
        //    {
        //        try
        //        {
        //            _context.Update(vehicleModel);
        //            await _context.SaveChangesAsync();
        //        }
        //        catch (DbUpdateConcurrencyException)
        //        {
        //            if (!VehicleModelExists(vehicleModel.Id))
        //            {
        //                return NotFound();
        //            }
        //            else
        //            {
        //                throw;
        //            }
        //        }
        //        return RedirectToAction(nameof(Index));
        //    }
        //    return View(vehicleModel);
        //}

        // GET: VehicleModels/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            //if (id == null)
            //{
            //    return NotFound();
            //}

            //var vehicleModel = await _context.VehicleModels
            //    .FirstOrDefaultAsync(m => m.Id == id);
            //if (vehicleModel == null)
            //{
            //    return NotFound();
            //}

            //return View(vehicleModel);
            return View();
        }

        // POST: VehicleModels/Delete/5
        //[HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> DeleteConfirmed(int id)
        //{
        //    var vehicleModel = await _context.VehicleModels.FindAsync(id);
        //    _context.VehicleModels.Remove(vehicleModel);
        //    await _context.SaveChangesAsync();
        //    return RedirectToAction(nameof(Index));
        //}

        //private bool VehicleModelExists(int id)
        //{
        //    return _context.VehicleModels.Any(e => e.Id == id);
        //}
    }
}
