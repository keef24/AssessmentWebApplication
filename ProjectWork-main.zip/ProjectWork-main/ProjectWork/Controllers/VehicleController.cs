﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectWork.Controllers
{
    public class VehicleController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
