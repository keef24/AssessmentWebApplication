﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectWork.Controllers
{
    public class ControlCenterController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
