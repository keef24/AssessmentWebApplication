﻿using Microsoft.AspNetCore.Mvc;

namespace ProjectWork.Controllers
{
    public class MakeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
