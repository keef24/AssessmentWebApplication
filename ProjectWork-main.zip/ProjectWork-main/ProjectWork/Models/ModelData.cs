﻿using System;

namespace ProjectWork.Models
{
    public class ModelData
    {
    }

    // Base class for Vehicle
    public class Vehicle
    {
        // Properties
        public int Make { get; set; }
        public int Model { get; set; }
        public int Year { get; set; }
        public double AverageSpeed { get; set; }

        // Methods
        public void Drive()
        {
            Console.WriteLine("The vehicle is now driving.");
        }

        public void Stop()
        {
            Console.WriteLine("The vehicle has stopped.");
        }

        public void Reverse()
        {
            Console.WriteLine("The vehicle is now reversing.");
        }
    }

    // Derived class Car from Vehicle
    public class Car : Vehicle
    {
        // Additional Car-specific properties
        public int NumberOfDoors { get; set; }
        public bool IsConvertible { get; set; }

        // Foreign Keys
        public int MakeId { get; set; }
        public int ModelId { get; set; }
    }

    // Derived class Truck from Vehicle
    public class Truck : Vehicle
    {
        // Additional Truck-specific properties
        public double LoadCapacityTons { get; set; }
        public bool HasTrailer { get; set; }

        // Foreign Keys
        public int MakeId { get; set; }
        public int ModelId { get; set; }
    }

    // Make and Model classes
    public class Make
    {
        public int MakeId { get; set; }
        public string MakeName { get; set; }
    }

    public class Model
    {
        public int ModelId { get; set; }
        public string ModelName { get; set; }
        public int Year { get; set; }
    }

}
